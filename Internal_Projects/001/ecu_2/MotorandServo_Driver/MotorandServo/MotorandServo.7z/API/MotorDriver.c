#include "MotorDriver.h"

FUNC(void, MOTORDRIVER_CODE)
MotorDriver_Init
(
    P2CONST(MotorDriver_ConfigType, AUTOMATIC, MOTORDRIVER_APPL_CONST) ConfigPtr
)
{
    MotorA_Init(ConfigPtr->PwmCh_ENAPin, ConfigPtr->DioCh_IN1Pin, ConfigPtr->DioCh_IN2Pin);
    MotorB_Init(ConfigPtr->PwmCh_ENBPin, ConfigPtr->DioCh_IN3Pin, ConfigPtr->DioCh_IN4Pin);
    StopMovement();
}

FUNC(void, MOTORDRIVER_CODE) MoveForward(VAR(void, AUTOMATIC))
{
    forwardA();
    forwardB();
}

FUNC(void, MOTORDRIVER_CODE) MoveBackward(VAR(void, AUTOMATIC))
{
    backwardA();
    backwardB();
}

FUNC(void, MOTORDRIVER_CODE) StopMovement(VAR(void, AUTOMATIC))
{
    stopA();
    stopB();
}