#ifndef SERVO_H
#define SERVO_H

#define SERVO_CODE

/* Uncomment the line corresponding to the desired SERVO to be used */
/* #define SERVO_180 */ /* servo is not continuous in turning */
#define SERVO_360       /* servo is continuous in turning */

#include "Mcu.h"
// #include "Port.h"
#include "Pwm.h"
#include "system.h"

typedef enum
{
    CLKWISE = 0,
    CNTRCLKWISE = 1,
    CENTER = -1
} ServoDirection;

typedef struct
{
    Pwm_ChannelType PwmChannel_Servo;
    uint16 pwmVal;
    boolean canMove;
    boolean isTurning;
    ServoDirection direction;
} Servo_ConfigType;

FUNC(void, SERVO_CODE) Servo_Init(VAR(Pwm_ChannelType, AUTOMATIC) ServoPwm_Channel);
#ifdef SERVO_180
FUNC(void, SERVO_CODE) Servo_TurnNeg90(VAR(void, AUTOMATIC));
FUNC(void, SERVO_CODE) Servo_TurnPos90(VAR(void, AUTOMATIC));
FUNC(void, SERVO_CODE) Servo_TurnZeroDeg(VAR(void, AUTOMATIC));
#endif /* SERVO_180 */

#ifdef SERVO_360
FUNC(void, SERVO_CODE) Servo_TurnNegDeg(VAR(void, AUTOMATIC));
FUNC(void, SERVO_CODE) Servo_TurnPosDeg(VAR(void, AUTOMATIC));
FUNC(void, SERVO_CODE) Servo_TurnZeroDeg(VAR(void, AUTOMATIC));
FUNC(void, SERVO_CODE) Servo_Stop(VAR(void, AUTOMATIC));
#endif /* SERVO_360 */
#endif /* SERVO_H */
