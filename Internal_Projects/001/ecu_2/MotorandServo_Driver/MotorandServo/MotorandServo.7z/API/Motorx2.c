#include "Motorx2.h"

L298N_ConfigType MotorDriverA;

FUNC(void, MOTORX2_CODE) MotorA_Init(uint16 pinEN, uint16 pinIN1, uint16 pinIN2)
{
    Motor_Init(&MotorDriverA.MotorA, pinEN, pinIN1, pinIN2);
    stop(&MotorDriverA.MotorA);
}
FUNC(void, MOTORX2_CODE) forwardA(VAR(void, AUTOMATIC))
{
    forward(&MotorDriverA.MotorA);
}
FUNC(void, MOTORX2_CODE) backwardA(VAR(void, AUTOMATIC))
{
    backward(&MotorDriverA.MotorA);
}
FUNC(void, MOTORX2_CODE) stopA(VAR(void, AUTOMATIC))
{
    stop(&MotorDriverA.MotorA);
}
FUNC(void, MOTORX1_CODE) setSpeedA(VAR(uint16, AUTOMATIC) PwmDutyCyle)
{
    setSpeed(&MotorDriverA.MotorA, PwmDutyCyle);
}

FUNC(void, MOTORX2_CODE) MotorB_Init(uint16 pinEN, uint16 pinIN1, uint16 pinIN2)
{
    Motor_Init(&MotorDriverA.MotorB, pinEN, pinIN1, pinIN2);
    stop(&MotorDriverA.MotorB);
}
FUNC(void, MOTORX2_CODE) forwardB(VAR(void, AUTOMATIC))
{
    forward(&MotorDriverA.MotorB);
}
FUNC(void, MOTORX2_CODE) backwardB(VAR(void, AUTOMATIC))
{
    backward(&MotorDriverA.MotorB);
}
FUNC(void, MOTORX2_CODE) stopB(VAR(void, AUTOMATIC))
{
    stop(&MotorDriverA.MotorB);
}
FUNC(void, MOTORX1_CODE) setSpeedB(VAR(uint16, AUTOMATIC) PwmDutyCyle)
{
    setSpeed(&MotorDriverA.MotorB, PwmDutyCyle);
}