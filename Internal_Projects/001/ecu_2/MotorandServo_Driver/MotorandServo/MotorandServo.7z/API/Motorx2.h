#ifndef MOTORX2_H
#define MOTORX2_H

#define MOTORX2_CODE

#include "Motorx1.h"

typedef struct
{
    Motor_ConfigType MotorA;
    Motor_ConfigType MotorB;
} L298N_ConfigType;

FUNC(void, MOTORX2_CODE) MotorA_Init(uint16 pinEN, uint16 pinIN1, uint16 pinIN2);
FUNC(void, MOTORX2_CODE) forwardA(VAR(void, AUTOMATIC));
FUNC(void, MOTORX2_CODE) backwardA(VAR(void, AUTOMATIC));
FUNC(void, MOTORX2_CODE) stopA(VAR(void, AUTOMATIC));
FUNC(void, MOTORX1_CODE) setSpeedA(VAR(uint16, AUTOMATIC) PwmDutyCyle);

FUNC(void, MOTORX2_CODE) MotorB_Init(uint16 pinEN, uint16 pinIN1, uint16 pinIN2);
FUNC(void, MOTORX2_CODE) forwardB(VAR(void, AUTOMATIC));
FUNC(void, MOTORX2_CODE) backwardB(VAR(void, AUTOMATIC));
FUNC(void, MOTORX2_CODE) stopB(VAR(void, AUTOMATIC));
FUNC(void, MOTORX1_CODE) setSpeedB(VAR(uint16, AUTOMATIC) PwmDutyCyle);

#endif /* MOTORX2_H */