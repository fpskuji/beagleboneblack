#include "Servo.h"

Servo_ConfigType Servo;

FUNC(void, SERVO_CODE) Servo_Init(VAR(Pwm_ChannelType, AUTOMATIC) ServoPwm_Channel)
{
    Servo.PwmChannel_Servo = ServoPwm_Channel;
    Servo.canMove = TRUE;
    Servo.isTurning = FALSE;
    Servo.direction = CENTER;
#ifdef SERVO_180
    Servo.pwmVal = 0x0000;
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x0000);
#endif
#ifdef SERVO_360
    Servo.pwmVal = 0x999;
    Servo_Stop();
#endif
}
#ifdef SERVO_180
FUNC(void, SERVO_CODE) Servo_TurnNeg90(VAR(void, AUTOMATIC))
{
    /* -90deg */
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x1000);
}
FUNC(void, SERVO_CODE) Servo_TurnPos90(VAR(void, AUTOMATIC))
{
    /* +90deg */
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x333);
}
FUNC(void, SERVO_CODE) Servo_TurnZeroDeg(VAR(void, AUTOMATIC))
{
    /* 0deg */
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x999);
}
#endif /* SERVO_180 */

#ifdef SERVO_360
FUNC(void, SERVO_CODE) Servo_TurnNegDeg(VAR(void, AUTOMATIC))
{
    /* -90deg */
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x1000);
    delay_ms(500);
    Servo_Stop();
}
FUNC(void, SERVO_CODE) Servo_TurnPosDeg(VAR(void, AUTOMATIC))
{
    /* +90deg */
    // Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x333);
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x666);
    delay_ms(500);
    Servo_Stop();
}
FUNC(void, SERVO_CODE) Servo_TurnZeroDeg(VAR(void, AUTOMATIC))
{
    /* 0deg */
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x999);
    delay_ms(500);
    Servo_Stop();
}
FUNC(void, SERVO_CODE) Servo_Stop(VAR(void, AUTOMATIC))
{
    Pwm_SetDutyCycle(Servo.PwmChannel_Servo, 0x999);
}
#endif /* SERVO_360 */