#include "main.h"

#define SW2_PRESSED    (Dio_ReadChannel(DioConf_DioChannel_SW2) == STD_HIGH)
#define SW3_PRESSED    (Dio_ReadChannel(DioConf_DioChannel_SW3) == STD_HIGH)
#define SpdUp_PRESSED  (Dio_ReadChannel(DioConf_DioChannel_SpdUp) == STD_HIGH)
#define SpdDwn_PRESSED (Dio_ReadChannel(DioConf_DioChannel_SpdDwn) == STD_HIGH)

CONST(MotorDriver_ConfigType, MOTORDRIVER_CONST)
MotorDriver_Config = {PwmCh_EnA, DioConf_DioChannel_IN1, DioConf_DioChannel_IN2,
                      PwmCh_EnB, DioConf_DioChannel_IN3, DioConf_DioChannel_IN4};
volatile uint16 pwmVal = 0;

int main()
{
    Mcu_Init(&Mcu_Config);
    Mcu_InitClock(McuClockSettingConfig_0);
    Port_Init(&Port_Config);
    Pwm_Init(&Pwm_Config);

    Systick_Init(SystemCoreClock / 1000);
    MotorDriver_Init(&MotorDriver_Config);
    Servo_Init(PwmCh_Servo);
    RGB_OFF();
    /*
    1ms     leftmost    0x666
    1.5ms   middle      0x999
    2ms     rightmost   0xCCC

     */
    // pwm_dc = e^(rpm)
    // rpm = ln(pwm_dc)
    while (1)
    {
        Pwm_SetDutyCycle(PwmCh_Servo, 0x666);
        delay_ms(20);
        Pwm_SetDutyCycle(PwmCh_Servo, 0x999);

        if (SW2_PRESSED)
        {
            MoveForward();
        }
        else if (SW3_PRESSED)
        {
            MoveBackward();
        }
        else
        {
            ;
        }

        if (SpdUp_PRESSED)
        {
            // pwmVal = Pwm_GetChannelState(PwmCh_EnA);
            // pwmVal = (pwmVal >= 0x8000) ? 0x8000 : (pwmVal + 3276);
            // setSpeedA(pwmVal);
            // setSpeedB(pwmVal);
            LEDRED_ON();
            // Pwm_SetDutyCycle(PwmCh_Servo, 0x666);
            // pwmVal = (pwmVal >= 0x8000) ? 0x8000 : (pwmVal + 10);
            // Pwm_SetDutyCycle(PwmCh_Servo, pwmVal);
            // Servo_TurnPosDeg();
        }
        else if (SpdDwn_PRESSED)
        {
            // pwmVal = Pwm_GetChannelState(PwmCh_EnA);
            // pwmVal = (pwmVal <= 0xCCC) ? 0xCCC : (pwmVal - 3276);
            // setSpeedA(pwmVal);
            // setSpeedB(pwmVal);
            LEDGREEN_ON();
            // Pwm_SetDutyCycle(PwmCh_Servo, 0x333);
            // pwmVal = (pwmVal <= 0x0000) ? 0x0000 : (pwmVal - 10);
            Pwm_SetDutyCycle(PwmCh_Servo, pwmVal);
            // Servo_TurnNegDeg();
        }
        else if (SW2_PRESSED)
        {
            LEDBLUE_ON();
            // Pwm_SetDutyCycle(PwmCh_Servo, 0xCCC);
            Servo_TurnZeroDeg();
        }
        else
        {
            RGB_OFF();
        }
    }
}
